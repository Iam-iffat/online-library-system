// KnowledgeHub - Online Library System
// Simple Vanilla JavaScript for the website

const sampleBooks = [
    { id: 1, title: "Computer Architecture", author: "John L. Hennessy", genre: "Computer Science", year: 2017, status: "Available", desc: "A practical introduction to processor design, performance, memory, and modern computer architecture.", image: "images/computer-architecture.png" },
    { id: 2, title: "Clean Code", author: "Robert C. Martin", genre: "Computer Science", year: 2008, status: "Available", desc: "A handbook of agile software craftsmanship, readable code, testing, and better programming practices.", image: "images/clean-code.png" },
    { id: 3, title: "To Kill a Mockingbird", author: "Harper Lee", genre: "Literature", year: 1960, status: "Borrowed", desc: "A classic novel exploring childhood, justice, innocence, and social inequality in the American South.", image: "images/to-kill-a-mockingbird.png" },
    { id: 4, title: "Principles of Physics", author: "David Halliday", genre: "Physics", year: 2014, status: "Available", desc: "A foundation in mechanics, thermodynamics, waves, electricity, magnetism, and modern physics.", image: "images/principles-of-physics.png" },
    { id: 5, title: "A Brief History of Time", author: "Stephen Hawking", genre: "Physics", year: 1988, status: "Available", desc: "An accessible exploration of cosmology, black holes, space, time, and the origin of the universe.", image: "images/brief-history-of-time.png" },
    { id: 6, title: "Sapiens: A Brief History", author: "Yuval Noah Harari", genre: "History", year: 2014, status: "Borrowed", desc: "A broad history of humankind and the major cognitive, agricultural, and scientific revolutions.", image: "images/sapiens.png" },
    { id: 7, title: "Artificial Intelligence Essentials", author: "Stuart Russell", genre: "Computer Science", year: 2026, status: "Available", desc: "A new-arrival guide to intelligent systems, machine learning, agents, and responsible AI.", image: "images/artificial-intelligence-essentials.png" },
    { id: 8, title: "Modern Web Development", author: "Ethan Brown", genre: "Computer Science", year: 2026, status: "Available", desc: "A practical introduction to modern HTML, CSS, JavaScript, responsive design, and web applications.", image: "images/modern-web-development.png" },
    { id: 9, title: "Data Science for Everyone", author: "Joel Grus", genre: "Computer Science", year: 2026, status: "Available", desc: "A beginner-friendly overview of data analysis, visualization, statistics, and machine learning concepts.", image: "images/data-science-for-everyone.png" },
    { id: 10, title: "The New Science Reader", author: "Neil deGrasse Tyson", genre: "Physics", year: 2026, status: "Available", desc: "A contemporary collection of readable science topics designed for curious students and researchers.", image: "images/new-science-reader.png" }
];

let currentUser = JSON.parse(localStorage.getItem('lib_user')) || { name: 'Rahim Ahmed', id: 'BC-8821-2026', dept: 'Computer Science' };
let borrowedBooks = JSON.parse(localStorage.getItem('lib_borrowed')) || [1];
let wishlistBooks = JSON.parse(localStorage.getItem('lib_wishlist')) || [2];
let occasionSelection = [];

function switchView(viewId) {
    document.querySelectorAll('.page-view').forEach(view => view.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));

    const targetView = document.getElementById(`view-${viewId}`);
    const targetBtn = document.getElementById(`nav-${viewId}`);
    if (targetView) targetView.classList.add('active');
    if (targetBtn) targetBtn.classList.add('active');

    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function bookCover(book) {
    return `<div class="book-cover">
        <img class="book-cover-image" src="${book.image}" alt="${book.title} cover" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
        <div class="cover-inner" style="display:none;">
            <i class="fa-solid fa-book-open"></i>
            <span>${book.title}</span>
            <small>${book.year}</small>
        </div>
        <span class="book-status ${book.status === 'Available' ? 'status-available' : 'status-borrowed'}">${book.status}</span>
    </div>`;
}

function renderBookCard(book, options = {}) {
    const isWishlisted = wishlistBooks.includes(book.id);
    const selectable = options.selectable || false;
    const selected = occasionSelection.includes(book.id);

    return `<article class="book-card">
        ${bookCover(book)}
        <div class="book-info">
            <div class="book-meta">${book.genre} • ${book.year}</div>
            <div class="book-title">${book.title}</div>
            <div class="book-author">By ${book.author}</div>
            <p class="book-description">${book.desc}</p>
            <div class="book-actions">
                ${book.status === 'Available'
    ? `<button class="btn btn-dark" onclick="borrowBook(${book.id})">
        <i class="fa-solid fa-bookmark"></i> Borrow
       </button>`
    : `<button class="btn btn-outline-dark" disabled>
        <i class="fa-solid fa-bookmark"></i> Borrowed
       </button>`
}
                <button class="btn btn-outline-dark" onclick="toggleWishlist(${book.id})"><i class="${isWishlisted ? 'fa-solid' : 'fa-regular'} fa-heart"></i> ${isWishlisted ? 'Saved' : 'Save'}</button>
                ${selectable ? `<button class="occasion-select ${selected ? 'selected' : ''}" onclick="toggleOccasionBook(${book.id})"><i class="fa-solid fa-check"></i> ${selected ? 'Selected' : 'Pick'}</button>` : ''}
            </div>
        </div>
    </article>`;
}

function renderBookList(books, containerId, options = {}) {
    const container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML = books.length
        ? books.map(book => renderBookCard(book, options)).join('')
        : `<p class="empty-message">No books match your search.</p>`;
}

function populateGrids() {
    // Home: New Arrivals FIRST (4 books), then Featured Books (3 books).
    renderBookList(sampleBooks.filter(b => b.year === 2026).slice(0, 4), 'home-new-arrivals');
    renderBookList(sampleBooks.filter(b => b.year < 2026).slice(0, 3), 'home-featured-books');

    renderBookList(sampleBooks, 'catalog-books-list');
    renderBookList(sampleBooks.filter(b => b.year === 2026), 'arrivals-books-list');

    const authors = [...new Set(sampleBooks.map(b => b.author))];
    const authorContainer = document.getElementById('authors-list');
    if (authorContainer) {
        authorContainer.innerHTML = authors.map(a => `
            <div class="card">
                <h4 style="font-weight:700;"><i class="fa-solid fa-user-pen" style="color:var(--accent); margin-right:6px;"></i>${a}</h4>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-top:4px;">Senior Contributor & Academic Author</p>
            </div>`).join('');
    }

    renderBookList(sampleBooks.filter(b => wishlistBooks.includes(b.id)), 'wishlist-items-list');
    renderOccasionBooks();
    updateCounts();
    renderBorrowedView();
}

function filterBooks() {
    const search = document.getElementById('search-input');
    const genreSelect = document.getElementById('genre-filter');
    const query = (search ? search.value : '').toLowerCase().trim();
    const genre = genreSelect ? genreSelect.value : 'ALL';

    const filtered = sampleBooks.filter(b => {
        const matchesQuery = !query || b.title.toLowerCase().includes(query) || b.author.toLowerCase().includes(query) || b.genre.toLowerCase().includes(query);
        const matchesGenre = genre === 'ALL' || b.genre === genre;
        return matchesQuery && matchesGenre;
    });
    renderBookList(filtered, 'catalog-books-list');
}

function globalSearch() {
    const input = document.getElementById('global-search');
    const value = input ? input.value.trim() : '';
    if (value.length > 0) {
        const catalogSearch = document.getElementById('search-input');
        if (catalogSearch) catalogSearch.value = value;
        switchView('catalog');
        filterBooks();
    }
}

function clearGlobalSearch() {
    const input = document.getElementById('global-search');
    if (input) input.value = '';
}

function toggleWishlist(id) {
    wishlistBooks = wishlistBooks.includes(id)
        ? wishlistBooks.filter(item => item !== id)
        : [...wishlistBooks, id];
    localStorage.setItem('lib_wishlist', JSON.stringify(wishlistBooks));
    populateGrids();
}

function borrowBook(id) {
    if (!borrowedBooks.includes(id)) {
        borrowedBooks.push(id);
        localStorage.setItem('lib_borrowed', JSON.stringify(borrowedBooks));
        alert('Book successfully reserved! Check "My Borrowed Books" dashboard.');
    } else {
        alert('You have already borrowed this book.');
    }
    updateCounts();
    renderBorrowedView();
}

function returnBook(id) {
    borrowedBooks = borrowedBooks.filter(item => item !== id);
    localStorage.setItem('lib_borrowed', JSON.stringify(borrowedBooks));
    updateCounts();
    renderBorrowedView();
}

function updateCounts() {
    const borrowed = document.getElementById('borrowed-count');
    const wishlist = document.getElementById('wishlist-count');
    if (borrowed) borrowed.innerText = borrowedBooks.length;
    if (wishlist) wishlist.innerText = wishlistBooks.length;
}

function renderBorrowedView() {
    const container = document.getElementById('borrowed-items-list');
    if (!container) return;
    const items = sampleBooks.filter(b => borrowedBooks.includes(b.id));

    if (!items.length) {
        container.innerHTML = `<p class="empty-message">You have no active borrowed books.</p>`;
        return;
    }

    container.innerHTML = items.map(b => `
        <div class="borrowed-row">
            <div>
                <strong>${b.title}</strong>
                <div class="small-muted">By ${b.author} • Due Date: 14 days from today</div>
            </div>
            <button class="btn btn-outline-danger" onclick="returnBook(${b.id})">Return</button>
        </div>`).join('');
}

function toggleOccasionBook(id) {
    if (occasionSelection.includes(id)) {
        occasionSelection = occasionSelection.filter(item => item !== id);
    } else if (occasionSelection.length < 7) {
        occasionSelection.push(id);
    } else {
        alert('You can pick a maximum of 7 books for this special offer.');
        return;
    }
    renderOccasionBooks();
}

function renderOccasionBooks() {
    const container = document.getElementById('occasion-books');
    const count = document.getElementById('occasion-count');
    if (!container) return;
    const books = sampleBooks.slice(0, 7);
    container.innerHTML = books.map(book => renderBookCard(book, { selectable: true })).join('');
    if (count) count.innerText = occasionSelection.length;
}

function claimOccasionOffer() {
    if (occasionSelection.length !== 7) {
        alert('Please pick exactly 7 books to claim the special occasion offer.');
        return;
    }
    occasionSelection.forEach(id => {
        if (!borrowedBooks.includes(id)) borrowedBooks.push(id);
    });
    localStorage.setItem('lib_borrowed', JSON.stringify(borrowedBooks));
    alert('Your 7 selected books have been reserved successfully!');
    occasionSelection = [];
    updateCounts();
    renderBorrowedView();
    renderOccasionBooks();
}

function openNewArrivals() {
    switchView('arrivals');
}

function toggleAuthTab(type) {
    const login = type === 'login';
    document.getElementById('form-login').style.display = login ? 'block' : 'none';
    document.getElementById('form-register').style.display = login ? 'none' : 'block';
    document.getElementById('btn-tab-login').style.background = login ? '#f1f5f9' : 'none';
    document.getElementById('btn-tab-reg').style.background = login ? 'none' : '#f1f5f9';
}

function handleLogin(e) {
    e.preventDefault();
    currentUser.id = document.getElementById('login-id').value;
    localStorage.setItem('lib_user', JSON.stringify(currentUser));
    updateIDCard();
    switchView('membership');
}

function handleRegister(e) {
    e.preventDefault();
    currentUser.name = document.getElementById('reg-name').value;
    currentUser.dept = document.getElementById('reg-dept').value;
    localStorage.setItem('lib_user', JSON.stringify(currentUser));
    updateIDCard();
    switchView('membership');
}

function updateIDCard() {
    const name = document.getElementById('id-card-name');
    const number = document.getElementById('id-card-number');
    const dept = document.getElementById('id-card-dept');
    const loginBtn = document.getElementById('user-login-btn');
    if (name) name.innerText = currentUser.name;
    if (number) number.innerText = currentUser.id;
    if (dept) dept.innerText = `${currentUser.dept} (Regular)`;
    if (loginBtn) loginBtn.innerText = currentUser.name.split(' ')[0];
}

function selectPayMethod(el) {
    document.querySelectorAll('.pay-card').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
}

function handlePayment(e) {
    e.preventDefault();
    alert('Payment confirmation submitted successfully. Receipt dispatched to registered student email.');
    switchView('home');
}

window.onload = function () {
    populateGrids();
    updateIDCard();
};
